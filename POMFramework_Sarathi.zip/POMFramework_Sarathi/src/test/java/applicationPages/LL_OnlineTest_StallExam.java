package applicationPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LL_OnlineTest_StallExam extends BasePage {

	BasePage basepage = new BasePage();
	WebDriver driver;
	boolean stepstatus;
	public LL_OnlineTest_StallExam(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

		
	@FindBy(how = How.XPATH, using = "//span[1][text()='LLTEST (STALL) ']")
	WebElement LLTest_Stall;
	@FindBy(how = How.XPATH, using = "//a[1][text()='Online LLTest(STALL)']")
	WebElement OnlineLLTest;
	
	
	@FindBy(how = How.XPATH, using = "//a[text()='Stall ']")
	WebElement Stall;
	@FindBy(how = How.XPATH, using = "//a[text()='PICK VIP CANDIDATE FOR LL TEST']")
	WebElement PICKVIPCANDIDATEFORLLTEST;
	@FindBy(how = How.XPATH, using = "//input[@name='applNum']")
	WebElement ApplicationNumber;
	@FindBy(how = How.XPATH, using = "//input[@name='submit']")
	WebElement Submit;
	@FindBy(how = How.XPATH, using = "//input[@name='Vipconfirm']")
	WebElement Confirm;
	@FindBy(how = How.XPATH, using = "//span[@class='text-info']/text()/following::text()[1]")
	WebElement Capturedallowedmessage;
	@FindBy(how = How.XPATH, using = "//div[@class='col-md-3 col-md-offset-3 bold text-right']/following::text()[2]")
	WebElement PinNumber;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
